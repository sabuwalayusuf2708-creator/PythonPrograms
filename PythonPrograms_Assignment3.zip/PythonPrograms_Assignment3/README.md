# DevOps Assignment 3 - PythonPrograms

Repository: PythonPrograms
Deadline: 5 October 2026

This repository contains the 20 Python programs and matching test files required by DevOps Assignment 3.

## Run a program
From the repository root:

```bash
python -m Code.01_even_odd
```

Note: Python module names beginning with a number cannot be imported with the normal `from Code...` syntax. The assignment's guide uses `Code.Check_Even_Odd_Num.py` for Program 1, while the assignment PDF specifies numbered filenames. The files here follow the numbered filenames from the assignment PDF.

## Run tests
Install pytest if needed:

```bash
python -m pip install pytest
```

Then run an individual test:

```bash
pytest Test_Code/test_01_even_odd.py -v
```

Or run all tests:

```bash
pytest -v
```
